import { View, Text, ScrollView } from '@tarojs/components';
import { useState, useEffect } from 'react';
import { Network } from '@/network';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { ClusterScatterChart } from '@/components/chart/cluster-scatter';
import { BarChart } from '@/components/chart/bar-chart';
import { PieChart } from '@/components/chart/pie-chart';
import { LineChart } from '@/components/chart/line-chart';
import './index.css';

interface Game {
  id: string;
  name: string;
  rating: number;
  commentCount: number;
  tags: string[];
  category: string;
  playCount: number;
  platform: string;
}

interface ClusterInfo {
  label: string;
  count: number;
  avgRating: number;
  centroid: { x: number; y: number };
}

interface ScatterDataset {
  label: string;
  data: { x: number; y: number; name?: string }[];
  backgroundColor: string;
}

interface Report {
  summary: string;
  gameCount: number;
  platforms: string[];
  categories: string[];
  topTags: { tag: string; count: number }[];
  clustering: {
    silhouetteScore: number;
    inertia: number;
  };
  regression: {
    coefficient: number;
    intercept: number;
    r2: number;
    rmse: number;
  };
}

const IndexPage = () => {
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('data');
  const [games, setGames] = useState<Game[]>([]);
  const [report, setReport] = useState<Report | null>(null);
  const [clusterData, setClusterData] = useState<{
    datasets: ScatterDataset[];
    clusterInfo: ClusterInfo[];
  } | null>(null);
  const [featureData, setFeatureData] = useState<{
    labels: string[];
    values: { feature: string; importance: number }[];
  } | null>(null);
  const [regressionData, setRegressionData] = useState<{
    datasets: ScatterDataset[];
    equation: { formula: string };
  } | null>(null);
  const [tagData, setTagData] = useState<{
    labels: string[];
    values: number[];
  } | null>(null);
  const [elbowData, setElbowData] = useState<{
    labels: string[];
    values: number[];
    annotation: { optimalK: number; description: string };
  } | null>(null);

  // 加载数据
  const loadData = async () => {
    setLoading(true);
    try {
      const [gamesRes, reportRes, clusterRes, featureRes, regressionRes, tagRes, elbowRes] =
        await Promise.all([
          Network.request({ url: '/api/games' }),
          Network.request({ url: '/api/games/report' }),
          Network.request({ url: '/api/games/charts/cluster-scatter' }),
          Network.request({ url: '/api/games/charts/feature-importance' }),
          Network.request({ url: '/api/games/charts/regression-line' }),
          Network.request({ url: '/api/games/charts/tag-distribution' }),
          Network.request({ url: '/api/games/charts/elbow' }),
        ]);

      console.log('Games response:', gamesRes.data);
      console.log('Report response:', reportRes.data);
      console.log('Cluster response:', clusterRes.data);
      console.log('Feature response:', featureRes.data);
      console.log('Regression response:', regressionRes.data);
      console.log('Tag response:', tagRes.data);
      console.log('Elbow response:', elbowRes.data);

      if (gamesRes.data?.data) setGames(gamesRes.data.data);
      if (reportRes.data?.data) setReport(reportRes.data.data);
      if (clusterRes.data?.data) setClusterData(clusterRes.data.data);
      if (featureRes.data?.data) {
        const fd = featureRes.data.data;
        setFeatureData({
          labels: fd.labels,
          values: fd.datasets[0]?.data?.map((v: number, i: number) => ({
            feature: fd.labels[i],
            importance: v,
          })) || [],
        });
      }
      if (regressionRes.data?.data) {
        const rd = regressionRes.data.data;
        setRegressionData({
          datasets: rd.datasets,
          equation: rd.equation,
        });
      }
      if (tagRes.data?.data) {
        const td = tagRes.data.data;
        setTagData({
          labels: td.labels,
          values: td.datasets[0]?.data || [],
        });
      }
      if (elbowRes.data?.data) {
        const ed = elbowRes.data.data;
        setElbowData({
          labels: ed.labels,
          values: ed.datasets[0]?.data || [],
          annotation: ed.annotation,
        });
      }
    } catch (error) {
      console.error('Failed to load data:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // 渲染数据列表
  const renderDataList = () => (
    <ScrollView className="data-list" scrollY>
      {loading ? (
        Array.from({ length: 5 }).map((_, i) => (
          <View key={i} className="skeleton-card">
            <Skeleton className="h-12 w-full mb-2" />
            <Skeleton className="h-4 w-3/4 mb-2" />
            <Skeleton className="h-4 w-1/2" />
          </View>
        ))
      ) : (
        games.map((game) => (
          <Card key={game.id} className="game-card">
            <CardContent className="p-4">
              <View className="game-header">
                <Text className="game-name block text-base font-semibold">{game.name}</Text>
                <Badge variant="secondary">{game.platform}</Badge>
              </View>
              <View className="game-stats">
                <View className="stat-item">
                  <Text className="stat-label block">评分</Text>
                  <Text className="stat-value block text-lg font-bold text-primary">
                    {game.rating.toFixed(1)}
                  </Text>
                </View>
                <View className="stat-item">
                  <Text className="stat-label block">评论数</Text>
                  <Text className="stat-value block text-sm">
                    {game.commentCount >= 10000
                      ? (game.commentCount / 10000).toFixed(1) + '万'
                      : game.commentCount}
                  </Text>
                </View>
                <View className="stat-item">
                  <Text className="stat-label block">玩家数</Text>
                  <Text className="stat-value block text-sm">
                    {game.playCount >= 10000
                      ? (game.playCount / 10000).toFixed(1) + '万'
                      : game.playCount}
                  </Text>
                </View>
              </View>
              <View className="game-tags">
                {game.tags.slice(0, 4).map((tag) => (
                  <Badge key={tag} variant="outline" className="mr-1 mb-1 text-xs">
                    {tag}
                  </Badge>
                ))}
              </View>
            </CardContent>
          </Card>
        ))
      )}
    </ScrollView>
  );

  // 渲染聚类分析
  const renderClustering = () => (
    <ScrollView className="analysis-content" scrollY>
      {loading ? (
        <Skeleton className="h-80 w-full mb-4" />
      ) : (
        <>
          {/* 聚类散点图 */}
          {clusterData && (
            <ClusterScatterChart
              title="游戏聚类分析散点图"
              subtitle="基于评分与评论数的KMeans聚类结果"
              datasets={clusterData.datasets}
              clusterInfo={clusterData.clusterInfo}
            />
          )}

          {/* 肘部法则图 */}
          {elbowData && (
            <LineChart
              title="KMeans最优K值分析"
              subtitle="肘部法则 - 选择拐点处的K值"
              labels={elbowData.labels}
              datasets={[{
                label: '簇内平方和',
                data: elbowData.values,
                borderColor: '#36a2eb',
              }]}
              annotation={elbowData.annotation}
            />
          )}

          {/* 聚类统计信息 */}
          {report && (
            <Card>
              <CardContent className="p-4">
                <Text className="section-title block mb-3">聚类分析指标</Text>
                <View className="metrics-grid">
                  <View className="metric-item">
                    <Text className="metric-label block">轮廓系数</Text>
                    <Text className="metric-value block text-xl font-bold text-primary">
                      {report.clustering.silhouetteScore.toFixed(3)}
                    </Text>
                    <Text className="metric-hint block text-xs text-muted-foreground">
                      {report.clustering.silhouetteScore > 0.5 ? '聚类效果好' : '可进一步优化'}
                    </Text>
                  </View>
                  <View className="metric-item">
                    <Text className="metric-label block">簇内平方和</Text>
                    <Text className="metric-value block text-xl font-bold text-primary">
                      {report.clustering.inertia.toFixed(1)}
                    </Text>
                    <Text className="metric-hint block text-xs text-muted-foreground">
                      值越小表示聚类越紧凑
                    </Text>
                  </View>
                  <View className="metric-item">
                    <Text className="metric-label block">游戏总数</Text>
                    <Text className="metric-value block text-xl font-bold text-primary">
                      {report.gameCount}
                    </Text>
                    <Text className="metric-hint block text-xs text-muted-foreground">
                      覆盖 {report.platforms.length} 个平台
                    </Text>
                  </View>
                  <View className="metric-item">
                    <Text className="metric-label block">游戏分类</Text>
                    <Text className="metric-value block text-xl font-bold text-primary">
                      {report.categories.length}
                    </Text>
                    <Text className="metric-hint block text-xs text-muted-foreground">
                      {report.categories.slice(0, 2).join(', ')}
                    </Text>
                  </View>
                </View>
              </CardContent>
            </Card>
          )}
        </>
      )}
    </ScrollView>
  );

  // 渲染回归分析
  const renderRegression = () => (
    <ScrollView className="analysis-content" scrollY>
      {loading ? (
        <Skeleton className="h-80 w-full mb-4" />
      ) : (
        <>
          {/* 回归拟合图 */}
          {regressionData && (
            <ClusterScatterChart
              title="评分-评论数回归分析"
              subtitle={`${regressionData.equation.formula}`}
              datasets={regressionData.datasets}
            />
          )}

          {/* 回归指标 */}
          {report && (
            <Card>
              <CardContent className="p-4">
                <Text className="section-title block mb-3">回归分析结果</Text>
                <View className="metrics-grid">
                  <View className="metric-item">
                    <Text className="metric-label block">R² 决定系数</Text>
                    <Text className="metric-value block text-xl font-bold text-primary">
                      {report.regression.r2.toFixed(4)}
                    </Text>
                    <Text className="metric-hint block text-xs text-muted-foreground">
                      {report.regression.r2 > 0.7
                        ? '拟合效果良好'
                        : report.regression.r2 > 0.4
                        ? '存在一定相关性'
                        : '相关性较弱'}
                    </Text>
                  </View>
                  <View className="metric-item">
                    <Text className="metric-label block">RMSE</Text>
                    <Text className="metric-value block text-xl font-bold text-primary">
                      {report.regression.rmse.toFixed(4)}
                    </Text>
                    <Text className="metric-hint block text-xs text-muted-foreground">
                      预测误差的均方根
                    </Text>
                  </View>
                  <View className="metric-item">
                    <Text className="metric-label block">回归系数</Text>
                    <Text className="metric-value block text-xl font-bold text-primary">
                      {report.regression.coefficient.toFixed(4)}
                    </Text>
                    <Text className="metric-hint block text-xs text-muted-foreground">
                      log(评论数)每增加1
                    </Text>
                  </View>
                  <View className="metric-item">
                    <Text className="metric-label block">截距</Text>
                    <Text className="metric-value block text-xl font-bold text-primary">
                      {report.regression.intercept.toFixed(4)}
                    </Text>
                    <Text className="metric-hint block text-xs text-muted-foreground">
                      基准评分估计
                    </Text>
                  </View>
                </View>

                <View className="regression-formula mt-4 p-3 bg-muted rounded-lg">
                  <Text className="formula-title block text-sm font-semibold mb-2">回归方程</Text>
                  <Text className="formula block text-center font-mono">
                    Rating = {report.regression.coefficient.toFixed(4)} × log(Comments + 1) + {report.regression.intercept.toFixed(4)}
                  </Text>
                  <Text className="formula-hint block text-xs text-center mt-2">
                    表明评论数与评分存在{report.regression.coefficient > 0 ? '正' : '负'}相关关系
                  </Text>
                </View>
              </CardContent>
            </Card>
          )}
        </>
      )}
    </ScrollView>
  );

  // 渲染特征分析
  const renderFeature = () => (
    <ScrollView className="analysis-content" scrollY>
      {loading ? (
        <Skeleton className="h-80 w-full mb-4" />
      ) : (
        <>
          {/* 特征重要性图 */}
          {featureData && (
            <BarChart
              title="特征重要性分析"
              subtitle="各特征对游戏评分的贡献度"
              labels={featureData.labels}
              datasets={[{
                label: '重要性得分',
                data: featureData.values.map(v => v.importance),
                backgroundColor: [
                  'rgba(255, 99, 132, 0.8)',
                  'rgba(54, 162, 235, 0.8)',
                  'rgba(255, 206, 86, 0.8)',
                  'rgba(75, 192, 192, 0.8)',
                ],
              }]}
              horizontal
            />
          )}

          {/* 标签分布图 */}
          {tagData && (
            <BarChart
              title="游戏标签分布TOP15"
              subtitle="最受欢迎的游戏标签"
              labels={tagData.labels}
              datasets={[{
                label: '出现次数',
                data: tagData.values,
                backgroundColor: tagData.labels.map((_, i) =>
                  `rgba(${50 + i * 15}, ${150 - i * 8}, ${200 - i * 10}, 0.8)`
                ),
              }]}
              horizontal
            />
          )}
        </>
      )}
    </ScrollView>
  );

  // 渲染报告
  const renderReport = () => (
    <ScrollView className="analysis-content" scrollY>
      {loading ? (
        <Skeleton className="h-40 w-full mb-4" />
      ) : (
        <>
          {/* 报告摘要 */}
          {report && (
            <Card className="mb-4">
              <CardContent className="p-4">
                <Text className="section-title block mb-3">分析报告摘要</Text>
                <Text className="report-summary block text-sm leading-relaxed">
                  {report.summary}
                </Text>
              </CardContent>
            </Card>
          )}

          {/* 平台分布 */}
          {report && (
            <PieChart
              title="游戏平台分布"
              subtitle="各平台游戏数量占比"
              labels={report.platforms}
              data={report.platforms.map(p => games.filter(g => g.platform === p).length)}
            />
          )}

          {/* 热门标签 */}
          {report && (
            <Card>
              <CardContent className="p-4">
                <Text className="section-title block mb-3">热门标签TOP10</Text>
                <View className="top-tags">
                  {report.topTags.map((item, idx) => (
                    <View key={item.tag} className="top-tag-item">
                      <Text className="tag-rank block text-primary font-bold">
                        {idx + 1}
                      </Text>
                      <Text className="tag-name block flex-1">{item.tag}</Text>
                      <Text className="tag-count block text-muted-foreground">
                        {item.count}次
                      </Text>
                    </View>
                  ))}
                </View>
              </CardContent>
            </Card>
          )}
        </>
      )}
    </ScrollView>
  );

  const tabs = [
    { value: 'data', label: '数据列表' },
    { value: 'cluster', label: '聚类分析' },
    { value: 'regression', label: '回归预测' },
    { value: 'feature', label: '特征分析' },
    { value: 'report', label: '分析报告' },
  ];

  return (
    <View className="page-container">
      {/* 头部 */}
      <View className="page-header">
        <Text className="page-title block text-xl font-bold">游戏数据分析系统</Text>
        <Text className="page-subtitle block text-sm text-muted-foreground">
          KMeans聚类 + 回归预测 + 可视化分析
        </Text>
      </View>

      {/* Tab切换 */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="page-tabs">
        <TabsList className="flex gap-1 p-1 bg-muted rounded-lg">
          {tabs.map((tab) => (
            <TabsTrigger
              key={tab.value}
              value={tab.value}
              className={`tab-trigger flex-1 py-2 px-2 text-xs rounded-md transition-colors ${
                activeTab === tab.value
                  ? 'bg-white shadow-sm text-foreground'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              <Text className="block">{tab.label}</Text>
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value="data" className="mt-4">
          {renderDataList()}
        </TabsContent>
        <TabsContent value="cluster" className="mt-4">
          {renderClustering()}
        </TabsContent>
        <TabsContent value="regression" className="mt-4">
          {renderRegression()}
        </TabsContent>
        <TabsContent value="feature" className="mt-4">
          {renderFeature()}
        </TabsContent>
        <TabsContent value="report" className="mt-4">
          {renderReport()}
        </TabsContent>
      </Tabs>
    </View>
  );
};

export default IndexPage;
