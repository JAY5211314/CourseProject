import { View, Text } from '@tarojs/components';
import './chart.scss';

interface ScatterPoint {
  x: number;
  y: number;
  name?: string;
}

interface ScatterDataset {
  label: string;
  data: ScatterPoint[];
  backgroundColor: string;
}

interface ClusterScatterProps {
  title: string;
  subtitle?: string;
  datasets: ScatterDataset[];
  clusterInfo?: {
    label: string;
    count: number;
    avgRating: number;
    centroid: { x: number; y: number };
  }[];
}

export function ClusterScatterChart({
  title,
  subtitle,
  datasets,
  clusterInfo = [],
}: ClusterScatterProps) {
  // 计算数据范围
  const allPoints = datasets.flatMap(d => d.data);
  const minX = Math.min(...allPoints.map(p => p.x));
  const maxX = Math.max(...allPoints.map(p => p.x));
  const minY = Math.min(...allPoints.map(p => p.y));
  const maxY = Math.max(...allPoints.map(p => p.y));

  // 坐标转换（百分比）
  const getX = (x: number) => ((x - minX) / (maxX - minX)) * 100;
  const getY = (y: number) => ((maxY - y) / (maxY - minY)) * 100;

  return (
    <View className="chart-container">
      <View className="chart-header">
        <Text className="chart-title block">{title}</Text>
        {subtitle && <Text className="chart-subtitle block">{subtitle}</Text>}
      </View>

      <View className="scatter-chart">
        {/* Y轴标签 */}
        <View className="y-axis">
          <Text className="axis-label">{maxY.toFixed(1)}</Text>
          <Text className="axis-label">{((minY + maxY) / 2).toFixed(1)}</Text>
          <Text className="axis-label">{minY.toFixed(1)}</Text>
        </View>

        {/* 图表区域 */}
        <View className="chart-area">
          {/* 散点 */}
          {datasets.map((dataset, dIdx) =>
            dataset.data.map((point, pIdx) => (
              <View
                key={`${dIdx}-${pIdx}`}
                className="scatter-point"
                style={{
                  left: `${getX(point.x)}%`,
                  top: `${getY(point.y)}%`,
                  backgroundColor: dataset.backgroundColor,
                }}
              >
                {point.name && (
                  <View className="point-tooltip">
                    <Text className="tooltip-name block">{point.name}</Text>
                    <Text className="tooltip-info block">
                      评分: {point.y.toFixed(1)} | 评论: {point.x >= 10000 ? (point.x / 10000).toFixed(1) + '万' : point.x}
                    </Text>
                  </View>
                )}
              </View>
            ))
          )}

          {/* X轴 */}
          <View className="x-axis-line" />

          {/* Y轴 */}
          <View className="y-axis-line" />
        </View>

        {/* X轴标签 */}
        <View className="x-axis">
          <Text className="axis-label">0</Text>
          <Text className="axis-label">{((minX + maxX) / 4 / 10000).toFixed(0)}万</Text>
          <Text className="axis-label">{((minX + maxX) / 2 / 10000).toFixed(0)}万</Text>
          <Text className="axis-label">{(maxX / 10000).toFixed(0)}万</Text>
        </View>
      </View>

      {/* 图例 */}
      <View className="chart-legend">
        {datasets.map((dataset, idx) => (
          <View key={idx} className="legend-item">
            <View
              className="legend-color"
              style={{ backgroundColor: dataset.backgroundColor }}
            />
            <Text className="legend-label">{dataset.label}</Text>
          </View>
        ))}
      </View>

      {/* 聚类信息 */}
      {clusterInfo.length > 0 && (
        <View className="cluster-info">
          {clusterInfo.map((info, idx) => (
            <View key={idx} className="cluster-card">
              <Text className="cluster-label block">{info.label}</Text>
              <View className="cluster-stats">
                <Text className="stat-item block">数量: {info.count}</Text>
                <Text className="stat-item block">均分: {info.avgRating}</Text>
              </View>
            </View>
          ))}
        </View>
      )}
    </View>
  );
}
