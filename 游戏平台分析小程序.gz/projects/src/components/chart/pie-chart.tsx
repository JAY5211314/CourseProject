import { View, Text } from '@tarojs/components';
import './chart.scss';

interface PieChartProps {
  title: string;
  subtitle?: string;
  labels: string[];
  data: number[];
  colors?: string[];
}

export function PieChart({ title, subtitle, labels, data, colors }: PieChartProps) {
  const total = data.reduce((sum, val) => sum + val, 0);
  const defaultColors = [
    'rgba(255, 99, 132, 0.8)',
    'rgba(54, 162, 235, 0.8)',
    'rgba(255, 206, 86, 0.8)',
    'rgba(75, 192, 192, 0.8)',
    'rgba(153, 102, 255, 0.8)',
  ];

  // 计算饼图扇形角度
  let currentAngle = 0;
  const segments = data.map((value, idx) => {
    const angle = (value / total) * 360;
    const segment = {
      label: labels[idx],
      value,
      percentage: ((value / total) * 100).toFixed(1),
      angle,
      startAngle: currentAngle,
      endAngle: currentAngle + angle,
      color: colors?.[idx] || defaultColors[idx % defaultColors.length],
    };
    currentAngle += angle;
    return segment;
  });

  return (
    <View className="chart-container">
      <View className="chart-header">
        <Text className="chart-title block">{title}</Text>
        {subtitle && <Text className="chart-subtitle block">{subtitle}</Text>}
      </View>

      <View className="pie-chart">
        {/* 简化的饼图展示 */}
        <View className="pie-visual">
          {segments.map((segment, idx) => (
            <View
              key={idx}
              className="pie-segment"
              style={{
                backgroundColor: segment.color,
                transform: `rotate(${segment.startAngle}deg)`,
                width: `${(segment.angle / 360) * 100}%`,
              }}
            />
          ))}
        </View>

        {/* 图例 */}
        <View className="pie-legend">
          {segments.map((segment, idx) => (
            <View key={idx} className="pie-legend-item">
              <View
                className="legend-color"
                style={{ backgroundColor: segment.color }}
              />
              <Text className="legend-label">{segment.label}</Text>
              <Text className="legend-value">{segment.percentage}%</Text>
            </View>
          ))}
        </View>
      </View>
    </View>
  );
}
