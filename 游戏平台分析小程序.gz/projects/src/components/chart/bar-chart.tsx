import { View, Text } from '@tarojs/components';
import './chart.scss';

interface BarChartProps {
  title: string;
  subtitle?: string;
  labels: string[];
  datasets: {
    label: string;
    data: number[];
    backgroundColor?: string[];
  }[];
  horizontal?: boolean;
}

export function BarChart({ title, subtitle, labels, datasets, horizontal = false }: BarChartProps) {
  const maxValue = Math.max(...datasets.flatMap(d => d.data));

  return (
    <View className="chart-container">
      <View className="chart-header">
        <Text className="chart-title block">{title}</Text>
        {subtitle && <Text className="chart-subtitle block">{subtitle}</Text>}
      </View>

      <View className={`bar-chart ${horizontal ? 'horizontal' : 'vertical'}`}>
        {datasets.map((dataset, dIdx) =>
          dataset.data.map((value, idx) => (
            <View key={`${dIdx}-${idx}`} className={`bar-item ${horizontal ? 'horizontal-bar' : ''}`}>
              {!horizontal && (
                <Text className="bar-label">{labels[idx]}</Text>
              )}
              <View className="bar-wrapper">
                <View
                  className="bar-fill"
                  style={{
                    height: horizontal ? '100%' : `${(value / maxValue) * 100}%`,
                    width: horizontal ? `${(value / maxValue) * 100}%` : '100%',
                    backgroundColor: dataset.backgroundColor?.[idx] || 'rgba(54, 162, 235, 0.8)',
                  }}
                >
                  <Text className="bar-value">{value.toFixed(2)}</Text>
                </View>
              </View>
              {horizontal && (
                <Text className="bar-label-horizontal">{labels[idx]}</Text>
              )}
            </View>
          ))
        )}
      </View>

      <View className="chart-legend">
        {datasets.map((dataset, idx) => (
          <View key={idx} className="legend-item">
            <View
              className="legend-color"
              style={{ backgroundColor: dataset.backgroundColor?.[0] || 'rgba(54, 162, 235, 0.8)' }}
            />
            <Text className="legend-label">{dataset.label}</Text>
          </View>
        ))}
      </View>
    </View>
  );
}
