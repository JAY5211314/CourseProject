import { View, Text } from '@tarojs/components';
import './chart.scss';

interface LineChartProps {
  title: string;
  subtitle?: string;
  labels: string[];
  datasets: {
    label: string;
    data: number[];
    borderColor?: string;
    fill?: boolean;
  }[];
  annotation?: {
    optimalK?: number;
    description?: string;
  };
}

export function LineChart({ title, subtitle, labels, datasets, annotation }: LineChartProps) {
  const allData = datasets.flatMap(d => d.data);
  const maxValue = Math.max(...allData);
  const minValue = Math.min(...allData);
  const range = maxValue - minValue || 1;

  return (
    <View className="chart-container">
      <View className="chart-header">
        <Text className="chart-title block">{title}</Text>
        {subtitle && <Text className="chart-subtitle block">{subtitle}</Text>}
      </View>

      <View className="line-chart">
        {/* Y轴 */}
        <View className="y-axis">
          <Text className="axis-label">{maxValue.toFixed(1)}</Text>
          <Text className="axis-label">{((maxValue + minValue) / 2).toFixed(1)}</Text>
          <Text className="axis-label">{minValue.toFixed(1)}</Text>
        </View>

        {/* 图表区域 */}
        <View className="chart-area">
          {/* 折线 */}
          <View className="line-wrapper">
            {datasets.map((dataset, dIdx) => (
              <View key={dIdx} className="line-path">
                {dataset.data.map((value, idx) => {
                  const x = (idx / (dataset.data.length - 1)) * 100;
                  const y = ((maxValue - value) / range) * 100;
                  return (
                    <View
                      key={idx}
                      className="line-point"
                      style={{
                        left: `${x}%`,
                        top: `${y}%`,
                        backgroundColor: dataset.borderColor || '#36a2eb',
                      }}
                    >
                      <View className="line-tooltip">
                        <Text className="tooltip-value block">{value.toFixed(2)}</Text>
                        <Text className="tooltip-label block">{labels[idx]}</Text>
                      </View>
                    </View>
                  );
                })}
              </View>
            ))}
          </View>

          {/* 标注点 */}
          {annotation?.optimalK && (
            <View
              className="annotation-marker"
              style={{
                left: `${((annotation.optimalK - 2) / 4) * 100}%`,
                bottom: '10%',
              }}
            >
              <View className="annotation-dot" />
              <Text className="annotation-text block">推荐K={annotation.optimalK}</Text>
            </View>
          )}

          {/* X轴标签 */}
          <View className="x-axis-labels">
            {labels.map((label, idx) => (
              <Text key={idx} className="x-label">{label}</Text>
            ))}
          </View>
        </View>
      </View>

      {annotation?.description && (
        <View className="chart-annotation">
          <Text className="annotation-info block">{annotation.description}</Text>
        </View>
      )}
    </View>
  );
}
