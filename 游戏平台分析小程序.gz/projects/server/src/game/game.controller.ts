import { Controller, Get, Query } from '@nestjs/common';
import { GameService } from './game.service';

@Controller('games')
export class GameController {
  constructor(private readonly gameService: GameService) {}

  /**
   * 获取所有游戏数据
   * GET /api/games
   */
  @Get()
  async getGames(@Query('refresh') refresh?: string) {
    const forceRefresh = refresh === 'true';
    return {
      code: 200,
      msg: 'success',
      data: await this.gameService.getGames(forceRefresh),
    };
  }

  /**
   * 获取聚类结果
   * GET /api/games/clustering?k=3
   */
  @Get('clustering')
  async getClustering(@Query('k') k?: string) {
    const kValue = k ? parseInt(k, 10) : 3;
    const result = await this.gameService.getClustering(kValue);
    return {
      code: 200,
      msg: 'success',
      data: result,
    };
  }

  /**
   * 获取回归分析结果
   * GET /api/games/regression
   */
  @Get('regression')
  async getRegression() {
    return {
      code: 200,
      msg: 'success',
      data: await this.gameService.getRegression(),
    };
  }

  /**
   * 获取特征重要性
   * GET /api/games/feature-importance
   */
  @Get('feature-importance')
  async getFeatureImportance() {
    return {
      code: 200,
      msg: 'success',
      data: await this.gameService.getFeatureImportance(),
    };
  }

  /**
   * 获取聚类散点图数据
   * GET /api/games/charts/cluster-scatter
   */
  @Get('charts/cluster-scatter')
  async getClusterScatterChart() {
    return {
      code: 200,
      msg: 'success',
      data: await this.gameService.getClusterScatterChart(),
    };
  }

  /**
   * 获取特征重要性图数据
   * GET /api/games/charts/feature-importance
   */
  @Get('charts/feature-importance')
  async getFeatureImportanceChart() {
    return {
      code: 200,
      msg: 'success',
      data: await this.gameService.getFeatureImportanceChart(),
    };
  }

  /**
   * 获取回归拟合图数据
   * GET /api/games/charts/regression-line
   */
  @Get('charts/regression-line')
  async getRegressionLineChart() {
    return {
      code: 200,
      msg: 'success',
      data: await this.gameService.getRegressionLineChart(),
    };
  }

  /**
   * 获取标签分布图数据
   * GET /api/games/charts/tag-distribution
   */
  @Get('charts/tag-distribution')
  async getTagDistributionChart() {
    return {
      code: 200,
      msg: 'success',
      data: await this.gameService.getTagDistributionChart(),
    };
  }

  /**
   * 获取平台分布图数据
   * GET /api/games/charts/platform-pie
   */
  @Get('charts/platform-pie')
  async getPlatformPieChart() {
    return {
      code: 200,
      msg: 'success',
      data: await this.gameService.getPlatformPieChart(),
    };
  }

  /**
   * 获取肘部法则图数据
   * GET /api/games/charts/elbow
   */
  @Get('charts/elbow')
  async getElbowChart() {
    return {
      code: 200,
      msg: 'success',
      data: await this.gameService.getElbowChart(),
    };
  }

  /**
   * 获取所有图表数据
   * GET /api/games/charts/all
   */
  @Get('charts/all')
  async getAllCharts() {
    return {
      code: 200,
      msg: 'success',
      data: await this.gameService.getAllCharts(),
    };
  }

  /**
   * 获取完整分析报告
   * GET /api/games/report
   */
  @Get('report')
  async getAnalysisReport() {
    return {
      code: 200,
      msg: 'success',
      data: await this.gameService.getAnalysisReport(),
    };
  }
}
