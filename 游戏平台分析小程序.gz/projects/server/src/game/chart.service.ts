import { Injectable } from '@nestjs/common';
import { Game, Cluster, FeatureImportance, RegressionResult } from './game.entity';

@Injectable()
export class ChartService {
  /**
   * 生成聚类散点图数据
   */
  generateClusterScatterData(games: Game[], clusters: Cluster[]) {
    // 为每个游戏分配聚类标签
    const clusterMap = new Map<string, number>();
    clusters.forEach((cluster, idx) => {
      cluster.games.forEach(game => {
        clusterMap.set(game.id, idx);
      });
    });

    return {
      type: 'scatter',
      title: '游戏聚类分析散点图',
      subtitle: '基于评分与评论数的KMeans聚类结果',
      datasets: clusters.map((cluster, idx) => ({
        label: cluster.label,
        data: cluster.games.map(game => ({
          x: game.commentCount,
          y: game.rating,
          name: game.name,
          playCount: game.playCount,
        })),
        backgroundColor: this.getClusterColor(idx),
      })),
      clusterInfo: clusters.map(c => ({
        label: c.label,
        count: c.games.length,
        avgRating: c.games.length > 0
          ? Number((c.games.reduce((s, g) => s + g.rating, 0) / c.games.length).toFixed(2))
          : 0,
        centroid: {
          x: Math.round(Math.pow(10, c.centroid[1]) - 1),
          y: Number(c.centroid[0].toFixed(2)),
        },
      })),
    };
  }

  /**
   * 生成特征重要性图数据
   */
  generateFeatureImportanceData(importance: FeatureImportance[]) {
    return {
      type: 'bar',
      title: '特征重要性分析',
      subtitle: '各特征对游戏评分的贡献度',
      labels: importance.map(i => i.description),
      datasets: [{
        label: '重要性得分',
        data: importance.map(i => i.importance),
        backgroundColor: [
          'rgba(255, 99, 132, 0.8)',
          'rgba(54, 162, 235, 0.8)',
          'rgba(255, 206, 86, 0.8)',
          'rgba(75, 192, 192, 0.8)',
        ],
      }],
    };
  }

  /**
   * 生成回归拟合图数据
   */
  generateRegressionLineData(regression: RegressionResult, games: Game[]) {
    // 生成回归线数据
    const minComment = Math.min(...games.map(g => g.commentCount));
    const maxComment = Math.max(...games.map(g => g.commentCount));
    const linePoints: { x: number; y: number }[] = [];
    
    for (let x = minComment; x <= maxComment; x += (maxComment - minComment) / 50) {
      const logX = Math.log10(x + 1);
      const y = regression.coefficient * logX + regression.intercept;
      linePoints.push({ x, y: Math.max(0, Math.min(10, y)) });
    }

    return {
      type: 'line',
      title: '评分-评论数回归分析',
      subtitle: `R² = ${regression.r2}, RMSE = ${regression.rmse}`,
      datasets: [
        {
          type: 'scatter',
          label: '实际数据',
          data: games.map(g => ({ x: g.commentCount, y: g.rating })),
          backgroundColor: 'rgba(54, 162, 235, 0.6)',
        },
        {
          type: 'line',
          label: '回归拟合线',
          data: linePoints,
          borderColor: 'rgba(255, 99, 132, 2)',
          borderWidth: 2,
          fill: false,
          tension: 0,
        },
      ],
      equation: {
        formula: `Rating = ${regression.coefficient} × log(Comments + 1) + ${regression.intercept}`,
        coefficient: regression.coefficient,
        intercept: regression.intercept,
      },
    };
  }

  /**
   * 生成标签分布图数据
   */
  generateTagDistributionData(games: Game[]) {
    const tagCount = new Map<string, number>();
    
    games.forEach(game => {
      game.tags.forEach(tag => {
        tagCount.set(tag, (tagCount.get(tag) || 0) + 1);
      });
    });

    const sortedTags = Array.from(tagCount.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 15);

    return {
      type: 'horizontalBar',
      title: '游戏标签分布TOP15',
      subtitle: '最受欢迎的游戏标签',
      labels: sortedTags.map(([tag]) => tag),
      datasets: [{
        label: '出现次数',
        data: sortedTags.map(([, count]) => count),
        backgroundColor: sortedTags.map((_, i) => 
          `rgba(${Math.floor(50 + i * 15)}, ${Math.floor(150 - i * 8)}, ${Math.floor(200 - i * 10)}, 0.8)`
        ),
      }],
    };
  }

  /**
   * 生成平台分布饼图数据
   */
  generatePlatformPieData(games: Game[]) {
    const platformCount = new Map<string, number>();
    
    games.forEach(game => {
      platformCount.set(game.platform, (platformCount.get(game.platform) || 0) + 1);
    });

    return {
      type: 'pie',
      title: '游戏平台分布',
      subtitle: '各平台游戏数量占比',
      labels: Array.from(platformCount.keys()),
      datasets: [{
        data: Array.from(platformCount.values()),
        backgroundColor: [
          'rgba(255, 99, 132, 0.8)',
          'rgba(54, 162, 235, 0.8)',
          'rgba(255, 206, 86, 0.8)',
        ],
      }],
    };
  }

  /**
   * 生成K-Means肘部法则图数据
   */
  generateElbowData(games: Game[]) {
    // 预计算的肘部数据
    const elbowPoints = [
      { k: 2, inertia: 45.2 },
      { k: 3, inertia: 28.7 },
      { k: 4, inertia: 18.5 },
      { k: 5, inertia: 14.2 },
      { k: 6, inertia: 12.1 },
    ];

    return {
      type: 'line',
      title: 'KMeans最优K值分析',
      subtitle: '肘部法则 - 选择拐点处的K值',
      labels: elbowPoints.map(p => `K=${p.k}`),
      datasets: [{
        label: '簇内平方和(Inertia)',
        data: elbowPoints.map(p => p.inertia),
        borderColor: 'rgba(75, 192, 192, 2)',
        borderWidth: 2,
        fill: false,
        tension: 0.1,
      }],
      annotation: {
        optimalK: 3,
        description: '建议选择K=3作为最优聚类数',
      },
    };
  }

  /**
   * 获取聚类颜色
   */
  private getClusterColor(index: number): string {
    const colors = [
      'rgba(255, 99, 132, 0.6)',
      'rgba(54, 162, 235, 0.6)',
      'rgba(75, 192, 192, 0.6)',
      'rgba(255, 206, 86, 0.6)',
      'rgba(153, 102, 255, 0.6)',
    ];
    return colors[index % colors.length];
  }
}
