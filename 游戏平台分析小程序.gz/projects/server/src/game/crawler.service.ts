import { Injectable } from '@nestjs/common';
import * as cheerio from 'cheerio';
import { Game } from './game.entity';

@Injectable()
export class CrawlerService {
  // 模拟游戏数据（实际环境中会从4399等平台爬取）
  private generateMockGameData(): Game[] {
    const platforms = ['4399', '7k7k', '3366'];
    const categories = ['休闲益智', '动作冒险', '射击游戏', '赛车竞速', '策略塔防', '角色扮演'];
    const tagPool = [
      '益智', '解谜', '敏捷', '射击', '动作', '冒险', '赛车', '跑酷',
      '模拟经营', '换装', '音乐', '儿童', '双人', '对战', '闯关',
      '消除', '拼图', '填色', '弹珠', '格斗', '塔防', ' RPG', 'SLG'
    ];

    const games: Game[] = [];
    const gameNames = [
      '森林冰火人', '植物大战僵尸', '愤怒的小鸟', '黄金矿工', '跑跑卡丁车',
      '穿越火线', 'CS反恐精英', '拳皇', '合金弹头', '超级玛丽',
      '俄罗斯方块', '连连看', '消消乐', '捕鱼达人', '神庙逃亡',
      '天天酷跑', '保卫萝卜', '三国杀', '斗地主', '麻将',
      '五子棋', '国际象棋', '数独', '华容道', '推箱子',
      '泡泡龙', '祖玛', '打字游戏', '拼图游戏', '找不同'
    ];

    for (let i = 0; i < 30; i++) {
      const name = gameNames[i] || `游戏${i + 1}`;
      const rating = Math.round((4 + Math.random() * 5.5) * 10) / 10; // 4.0-9.5
      const commentCount = Math.floor(Math.random() * 500000) + 1000; // 1000-501000
      const playCount = Math.floor(Math.random() * 10000000) + 10000; // 10000-10010000
      const tagCount = Math.floor(Math.random() * 4) + 2; // 2-5个标签
      const tags: string[] = [];
      
      for (let j = 0; j < tagCount; j++) {
        const tag = tagPool[Math.floor(Math.random() * tagPool.length)];
        if (!tags.includes(tag)) tags.push(tag);
      }

      games.push({
        id: `game_${i + 1}`,
        name,
        rating,
        commentCount,
        tags,
        category: categories[Math.floor(Math.random() * categories.length)],
        playCount,
        platform: platforms[Math.floor(Math.random() * platforms.length)],
        imageUrl: `https://via.placeholder.com/100x100?text=${encodeURIComponent(name)}`,
      });
    }

    return games;
  }

  /**
   * 从4399平台爬取游戏数据
   * 实际实现中会使用真实的HTTP请求
   */
  async crawl4399Games(): Promise<Game[]> {
    // 实际爬虫逻辑（模拟）
    // const response = await fetch('https://www.4399.com/flash/');
    // const $ = cheerio.load(response);
    // ... 解析HTML获取游戏数据

    // 返回模拟数据
    return this.generateMockGameData().filter(g => g.platform === '4399');
  }

  /**
   * 从7k7k平台爬取游戏数据
   */
  async crawl7k7kGames(): Promise<Game[]> {
    return this.generateMockGameData().filter(g => g.platform === '7k7k');
  }

  /**
   * 从3366平台爬取游戏数据
   */
  async crawl3366Games(): Promise<Game[]> {
    return this.generateMockGameData().filter(g => g.platform === '3366');
  }

  /**
   * 爬取所有平台的游戏数据
   */
  async crawlAllPlatforms(): Promise<Game[]> {
    const [games4399, games7k7k, games3366] = await Promise.all([
      this.crawl4399Games(),
      this.crawl7k7kGames(),
      this.crawl3366Games(),
    ]);

    return [...games4399, ...games7k7k, ...games3366];
  }

  /**
   * 数据清洗和标准化
   */
  normalizeData(games: Game[]): Game[] {
    return games.map(game => ({
      ...game,
      // 确保数值类型正确
      rating: Number(game.rating.toFixed(1)),
      commentCount: Number(game.commentCount),
      playCount: Number(game.playCount),
      // 去除空标签
      tags: game.tags.filter(t => t && t.trim()),
    }));
  }
}
