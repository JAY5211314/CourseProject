// 游戏数据实体
export interface Game {
  id: string;
  name: string;
  rating: number;        // 评分 0-10
  commentCount: number;   // 评论数
  tags: string[];         // 标签列表
  category: string;       // 游戏分类
  playCount: number;      // 玩家数量
  platform: string;        // 来源平台
  imageUrl?: string;      // 游戏图标
}

// 聚类结果
export interface ClusterResult {
  clusters: Cluster[];
  silhouetteScore: number;
  inertia: number;
}

export interface Cluster {
  id: number;
  games: Game[];
  centroid: number[];     // 质心 [rating, commentCount]
  label: string;          // 簇标签
}

// 回归分析结果
export interface RegressionResult {
  coefficient: number;
  intercept: number;
  r2: number;
  mse: number;
  rmse: number;
  predictions: Prediction[];
}

export interface Prediction {
  gameId: string;
  actualRating: number;
  predictedRating: number;
  residual: number;
}

// 特征重要性
export interface FeatureImportance {
  feature: string;
  importance: number;
  description: string;
}

// 可视化数据
export interface ChartData {
  type: 'scatter' | 'bar' | 'line';
  title: string;
  data: any;
}

// 分析报告
export interface AnalysisReport {
  summary: string;
  gameCount: number;
  platforms: string[];
  categories: string[];
  topTags: { tag: string; count: number }[];
  clustering: ClusterResult;
  regression: RegressionResult;
  featureImportance: FeatureImportance[];
}
