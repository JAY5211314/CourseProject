import { Module } from '@nestjs/common';
import { GameController } from './game.controller';
import { GameService } from './game.service';
import { CrawlerService } from './crawler.service';
import { MlService } from './ml.service';
import { ChartService } from './chart.service';

@Module({
  controllers: [GameController],
  providers: [GameService, CrawlerService, MlService, ChartService],
  exports: [GameService, CrawlerService, MlService, ChartService],
})
export class GameModule {}
