import { Injectable } from '@nestjs/common';
import { CrawlerService } from './crawler.service';
import { MlService } from './ml.service';
import { ChartService } from './chart.service';
import { Game, AnalysisReport, ClusterResult, RegressionResult, FeatureImportance } from './game.entity';

@Injectable()
export class GameService {
  // 缓存数据
  private cachedGames: Game[] | null = null;
  private cachedAnalysis: {
    games: Game[];
    clustering: ClusterResult;
    regression: RegressionResult;
    featureImportance: FeatureImportance[];
  } | null = null;

  constructor(
    private readonly crawlerService: CrawlerService,
    private readonly mlService: MlService,
    private readonly chartService: ChartService,
  ) {}

  /**
   * 获取所有游戏数据
   */
  async getGames(forceRefresh: boolean = false): Promise<Game[]> {
    if (this.cachedGames && !forceRefresh) {
      return this.cachedGames;
    }

    console.log('正在采集游戏数据...');
    const rawGames = await this.crawlerService.crawlAllPlatforms();
    this.cachedGames = this.crawlerService.normalizeData(rawGames);
    console.log(`采集完成，共 ${this.cachedGames.length} 款游戏`);

    return this.cachedGames;
  }

  /**
   * 获取聚类结果
   */
  async getClustering(k: number = 3): Promise<ClusterResult> {
    const games = await this.getGames();
    return this.mlService.kMeansClustering(games, k);
  }

  /**
   * 获取回归分析结果
   */
  async getRegression(): Promise<RegressionResult> {
    const games = await this.getGames();
    return this.mlService.linearRegression(games);
  }

  /**
   * 获取特征重要性
   */
  async getFeatureImportance(): Promise<FeatureImportance[]> {
    const games = await this.getGames();
    return this.mlService.featureImportance(games);
  }

  /**
   * 获取聚类散点图数据
   */
  async getClusterScatterChart() {
    const games = await this.getGames();
    const clustering = await this.getClustering();
    return this.chartService.generateClusterScatterData(games, clustering.clusters);
  }

  /**
   * 获取特征重要性图数据
   */
  async getFeatureImportanceChart() {
    const importance = await this.getFeatureImportance();
    return this.chartService.generateFeatureImportanceData(importance);
  }

  /**
   * 获取回归拟合图数据
   */
  async getRegressionLineChart() {
    const games = await this.getGames();
    const regression = await this.getRegression();
    return this.chartService.generateRegressionLineData(regression, games);
  }

  /**
   * 获取标签分布图数据
   */
  async getTagDistributionChart() {
    const games = await this.getGames();
    return this.chartService.generateTagDistributionData(games);
  }

  /**
   * 获取平台分布图数据
   */
  async getPlatformPieChart() {
    const games = await this.getGames();
    return this.chartService.generatePlatformPieData(games);
  }

  /**
   * 获取肘部法则图数据
   */
  async getElbowChart() {
    const games = await this.getGames();
    return this.chartService.generateElbowData(games);
  }

  /**
   * 获取完整分析报告
   */
  async getAnalysisReport(): Promise<AnalysisReport> {
    const games = await this.getGames();
    const clustering = await this.getClustering();
    const regression = await this.getRegression();
    const featureImportance = await this.getFeatureImportance();

    // 统计各平台和分类
    const platforms = [...new Set(games.map(g => g.platform))];
    const categories = [...new Set(games.map(g => g.category))];

    // 统计热门标签
    const tagCount = new Map<string, number>();
    games.forEach(game => {
      game.tags.forEach(tag => {
        tagCount.set(tag, (tagCount.get(tag) || 0) + 1);
      });
    });
    const topTags = Array.from(tagCount.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([tag, count]) => ({ tag, count }));

    // 生成摘要
    const avgRating = games.reduce((s, g) => s + g.rating, 0) / games.length;
    const totalComments = games.reduce((s, g) => s + g.commentCount, 0);
    const summary = `本报告分析了来自${platforms.length}个平台的${games.length}款游戏。` +
      `平均评分为${avgRating.toFixed(2)}分，总评论数达${(totalComments / 10000).toFixed(0)}万条。` +
      `KMeans聚类将游戏分为${clustering.clusters.length}类，回归分析R²=${regression.r2.toFixed(3)}，` +
      `表明评论数对评分有一定预测能力。`;

    return {
      summary,
      gameCount: games.length,
      platforms,
      categories,
      topTags,
      clustering,
      regression,
      featureImportance,
    };
  }

  /**
   * 获取所有图表数据
   */
  async getAllCharts() {
    const games = await this.getGames();
    const clustering = await this.getClustering();
    const regression = await this.getRegression();
    const importance = await this.getFeatureImportance();

    return {
      clusterScatter: this.chartService.generateClusterScatterData(games, clustering.clusters),
      featureImportance: this.chartService.generateFeatureImportanceData(importance),
      regressionLine: this.chartService.generateRegressionLineData(regression, games),
      tagDistribution: this.chartService.generateTagDistributionData(games),
      platformPie: this.chartService.generatePlatformPieData(games),
      elbow: this.chartService.generateElbowData(games),
    };
  }
}
