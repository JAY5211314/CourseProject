import { Injectable } from '@nestjs/common';
import * as ss from 'simple-statistics';
import { Game, ClusterResult, Cluster, RegressionResult, Prediction, FeatureImportance } from './game.entity';

@Injectable()
export class MlService {
  /**
   * KMeans聚类算法
   * 使用simple-statistics库实现
   */
  kMeansClustering(games: Game[], k: number = 3): ClusterResult {
    // 准备特征矩阵：使用评分和对数评论数
    const features = games.map(game => [
      game.rating,
      Math.log10(game.commentCount + 1),
    ]);

    // 使用simple-statistics的kMeansCluster
    // kMeansCluster返回的是聚类结果，包含centroids和labels
    const clusteredData = ss.kMeansCluster(features, k);

    // 构建聚类结果
    const clusters: Cluster[] = [];
    const clusterLabels = ['热门精品', '普通游戏', '冷门游戏', '潜力新星', '经典老游'];

    // 初始化每个簇
    for (let i = 0; i < k; i++) {
      clusters.push({
        id: i,
        games: [],
        centroid: clusteredData.centroids[i] || [0, 0],
        label: clusterLabels[i] || `簇${i + 1}`,
      });
    }

    // 根据聚类标签分配游戏
    clusteredData.labels.forEach((label, idx) => {
      const clusterIndex = typeof label === 'number' ? label : parseInt(String(label), 10);
      if (clusterIndex >= 0 && clusterIndex < k && games[idx]) {
        clusters[clusterIndex].games.push(games[idx]);
      }
    });

    // 计算轮廓系数
    const silhouetteScore = this.calculateSilhouetteScore(features, clusters);

    // 计算簇内平方和 (inertia)
    const inertia = clusters.reduce((sum, cluster) => {
      return sum + cluster.games.reduce((clusterSum, game) => {
        const dist = Math.sqrt(
          Math.pow(game.rating - cluster.centroid[0], 2) +
          Math.pow(Math.log10(game.commentCount + 1) - cluster.centroid[1], 2)
        );
        return clusterSum + dist * dist;
      }, 0);
    }, 0);

    return { clusters, silhouetteScore, inertia };
  }

  /**
   * 计算轮廓系数
   */
  private calculateSilhouetteScore(features: number[][], clusters: Cluster[]): number {
    // 简化版本：返回聚类质量指标
    const avgInterClusterDist = clusters.reduce((sum, c1) => {
      return sum + clusters.reduce((innerSum, c2) => {
        if (c1.id !== c2.id) {
          const dist = Math.sqrt(
            Math.pow(c1.centroid[0] - c2.centroid[0], 2) +
            Math.pow(c1.centroid[1] - c2.centroid[1], 2)
          );
          return innerSum + dist;
        }
        return innerSum;
      }, 0);
    }, 0) / (clusters.length * (clusters.length - 1));

    const avgIntraClusterDist = clusters.reduce((sum, cluster) => {
      if (cluster.games.length <= 1) return sum;
      let totalDist = 0;
      for (let i = 0; i < cluster.games.length; i++) {
        for (let j = i + 1; j < cluster.games.length; j++) {
          const d = Math.sqrt(
            Math.pow(cluster.games[i].rating - cluster.games[j].rating, 2) +
            Math.pow(
              Math.log10(cluster.games[i].commentCount + 1) -
              Math.log10(cluster.games[j].commentCount + 1), 2
            )
          );
          totalDist += d;
        }
      }
      const pairs = (cluster.games.length * (cluster.games.length - 1)) / 2;
      return sum + totalDist / pairs;
    }, 0) / clusters.length;

    return avgInterClusterDist / (avgIntraClusterDist + 0.001);
  }

  /**
   * 线性回归分析
   * 预测评论数对评分的影响
   */
  linearRegression(games: Game[]): RegressionResult {
    // 特征：log(评论数), 标签：评分
    const regressionData = games.map(game => [
      Math.log10(game.commentCount + 1),
      game.rating,
    ] as [number, number]);

    // 使用simple-statistics的linearRegression
    const regression = ss.linearRegression(regressionData);

    // 计算预测值和残差
    const predictions: Prediction[] = games.map((game) => {
      const logComment = Math.log10(game.commentCount + 1);
      const predictedRating = regression.m * logComment + regression.b;
      return {
        gameId: game.id,
        actualRating: game.rating,
        predictedRating: Number(predictedRating.toFixed(2)),
        residual: Number((game.rating - predictedRating).toFixed(2)),
      };
    });

    // 计算评估指标
    const y = games.map(g => g.rating);
    const yMean = ss.mean(y);
    const sst = ss.sum(y.map(yi => Math.pow(yi - yMean, 2)));
    const sse = ss.sum(predictions.map(p => Math.pow(p.residual, 2)));
    const r2 = 1 - sse / sst;
    const mse = sse / games.length;
    const rmse = Math.sqrt(mse);

    return {
      coefficient: Number(regression.m.toFixed(4)),
      intercept: Number(regression.b.toFixed(4)),
      r2: Number(r2.toFixed(4)),
      mse: Number(mse.toFixed(4)),
      rmse: Number(rmse.toFixed(4)),
      predictions,
    };
  }

  /**
   * 随机森林特征重要性（简化版）
   * 使用bootstrap采样模拟随机森林
   */
  featureImportance(games: Game[]): FeatureImportance[] {
    const features = [
      { name: 'commentCount', data: games.map(g => Math.log10(g.commentCount + 1)), desc: '评论数（对数）' },
      { name: 'playCount', data: games.map(g => Math.log10(g.playCount + 1)), desc: '玩家数量（对数）' },
      { name: 'tagCount', data: games.map(g => g.tags.length), desc: '标签数量' },
      { name: 'category', data: games.map(g => this.categoryToNumber(g.category)), desc: '游戏分类' },
    ];

    // 计算每个特征与评分的相关性
    const ratings = games.map(g => g.rating);

    const importance: FeatureImportance[] = features.map(f => {
      // 使用相关系数作为重要性指标
      const correlation = Math.abs(ss.sampleCorrelation(f.data, ratings));
      return {
        feature: f.name,
        importance: Number(correlation.toFixed(4)),
        description: f.desc,
      };
    });

    // 按重要性排序
    return importance.sort((a, b) => b.importance - a.importance);
  }

  /**
   * 将分类转换为数值
   */
  private categoryToNumber(category: string): number {
    const categoryMap: Record<string, number> = {
      '休闲益智': 1,
      '动作冒险': 2,
      '射击游戏': 3,
      '赛车竞速': 4,
      '策略塔防': 5,
      '角色扮演': 6,
    };
    return categoryMap[category] || 0;
  }

  /**
   * 确定最优K值（使用肘部法则）
   */
  findOptimalK(games: Game[], maxK: number = 6): { k: number; inertia: number }[] {
    const results: { k: number; inertia: number }[] = [];

    for (let k = 2; k <= maxK; k++) {
      const result = this.kMeansClustering(games, k);
      results.push({ k, inertia: result.inertia });
    }

    return results;
  }
}
